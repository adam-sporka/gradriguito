Open tutorial.gto in Notepad for instructions.
Then try building before-basics.gto